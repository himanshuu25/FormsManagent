package dao;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import dto.StudentDto;

public class StudentDao {

	public int insert(StudentDto sdto) throws Exception {
		InputStream in=StudentDao.class.getClassLoader().getResourceAsStream("database.properties");
		Properties p=new Properties();
		p.load(in);
		Class.forName(p.getProperty("driver"));
		Connection con = DriverManager.getConnection(p.getProperty("url") ,p.getProperty("user"),p.getProperty("password"));
		String sql = "INSERT INTO StudentInfo VALUES(?,?,?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, sdto.getFname());
		ps.setString(2, sdto.getLname());
		ps.setString(3, sdto.getRollno());
		ps.setLong(4, sdto.getMobile());
		ps.setString(5, sdto.getCourse());
		ps.setString(6, sdto.getBranch());
		int count=ps.executeUpdate();
		ps.close();
		con.close();
		if(count>0)
			return count;
		return count;
	}

	public StudentDto show(StudentDto sdto) throws Exception {
		InputStream in=StudentDao.class.getClassLoader().getResourceAsStream("database.properties");
		Properties p=new Properties();
		p.load(in);
		Class.forName(p.getProperty("driver"));
		Connection con = DriverManager.getConnection(p.getProperty("url") ,p);
		PreparedStatement ps = con.prepareStatement("SELECT * FROM StudentInfo WHERE rollno=?");
		ps.setString(1, sdto.getRollno());
		ResultSet rs = ps.executeQuery();
		sdto =new StudentDto();
		boolean flag=false;
		while(rs.next()){
		sdto.setFname(rs.getString(1));
		sdto.setLname(rs.getString(2));
		sdto.setRollno(rs.getString(3));
		sdto.setMobile(rs.getLong(4));
		sdto.setCourse(rs.getString(5));
		sdto.setBranch(rs.getString(6));
		flag=true;
		}
		rs.close();
		ps.close();
		con.close();
		if(flag) {
			return sdto;
		}
		return null;
	}

	public int edit(StudentDto oldsdto,StudentDto newsdto)throws Exception {
		InputStream in=StudentDao.class.getClassLoader().getResourceAsStream("database.properties");
		Properties p=new Properties();
		p.load(in);
		Class.forName(p.getProperty("driver"));
		Connection con = DriverManager.getConnection(p.getProperty("url") ,p);
		PreparedStatement ps = con.prepareStatement("UPDATE StudentInfo SET fname=?, lname=? WHERE fname=? AND lname=?");
        ps.setString(1, newsdto.getFname());		
        ps.setString(2, newsdto.getLname());	
        ps.setString(3, oldsdto.getFname());
        ps.setString(4, oldsdto.getLname());
       int count= ps.executeUpdate();
		ps.close();
		con.close();
		if(count>0)
			return count;
		return 0;
	}
	public int delete(StudentDto sdto)throws Exception {
		InputStream in=StudentDao.class.getClassLoader().getResourceAsStream("database.properties");
		Properties p=new Properties();
		p.load(in);
		Class.forName(p.getProperty("driver"));
		Connection con = DriverManager.getConnection(p.getProperty("url") ,p);
		PreparedStatement ps = con.prepareStatement("DELETE FROM StudentInfo WHERE rollno=?");
		ps.setString(1, sdto.getRollno());
		int count=ps.executeUpdate();
	    ps.close();
		con.close();
		if(count>0)
			return count;
		return 0;
	}
}
