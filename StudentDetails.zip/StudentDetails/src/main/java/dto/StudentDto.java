package dto;
import java.io.Serializable;

public class StudentDto implements Serializable {
   private String fname;
   private String lname;
   private String rollno;
   private long mobile;
   private String course;
   private String branch;
   public String getFname() {
	return fname;
}
   public void setFname(String fname) {
	this.fname = fname;
   }
   public String getLname() {
	return lname;
   }
   public void setLname(String lname) {
	this.lname = lname;
   }
   public String getRollno() {
	return rollno;
   }
   public void setRollno(String rollno) {
	this.rollno = rollno;
   }
   public long getMobile() {
	return mobile;
   }
   public void setMobile(long mobile) {
	this.mobile = mobile;
   }
   public String getCourse() {
	return course;
   }
   public void setCourse(String course) {
	this.course = course;
   }
   public String getBranch() {
	return branch;
   }
   public void setBranch(String branch) {
	this.branch = branch;
   }
  
}
