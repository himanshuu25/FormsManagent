package std.det;

import java.io.IOException;
import java.io.PrintWriter;

import dao.StudentDao;
import dto.StudentDto;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

public class InsertServlet extends GenericServlet {
	private static final long serialVersionUID = 1L;
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		StudentDto sdto = new StudentDto();
		sdto.setFname(req.getParameter("fname"));
		sdto.setLname(req.getParameter("lname"));
		sdto.setRollno(req.getParameter("rollno"));
		String mob = req.getParameter("mob");
		if (mob != null) {
			sdto.setMobile(Long.parseLong(mob));
		}
		sdto.setBranch(req.getParameter("branch"));
		sdto.setCourse(req.getParameter("course"));
		try {
		int status=new StudentDao().insert(sdto);
		 if(status>0){
			 out.println("<h2>Your Query Is Successfully Inserted</h2>");
    	  }
    	  else
 	         out.println("<h2>failed to insert try again</h2>");
    	  
    	  out.println("<a href=\"insert.html\">Go Back</a>");
		
		}catch(Exception e) {
			System.out.println("Unexpected Exception"+e);
		}
	}

}
