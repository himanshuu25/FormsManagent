package std.det;

import java.io.IOException;
import java.io.PrintWriter;

import dao.StudentDao;
import dto.StudentDto;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

public class ShowServlet extends GenericServlet {
	private static final long serialVersionUID = 1L;
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
	          StudentDto sdto=new StudentDto();
	          sdto.setRollno(req.getParameter("rollno"));
	          try {
	         sdto= new StudentDao().show(sdto);
	         if(sdto!=null){
	         out.println("<H2>Full Name :"+sdto.getFname()+" "+sdto.getLname()+"</H2>");
	         out.println("<H2>Entrollment Number :"+sdto.getRollno()+"</H2>");
	         out.println("<H2>Mobile Number :"+sdto.getMobile()+"</H2>");
	         out.println("<H2>Course :"+sdto.getCourse()+"</H2>");
	         out.println("<H2>Branch :"+sdto.getBranch()+"</H2>");
	         }
	         else{
	        	 out.println("<h2>data not found</h2>");
	         }
	         out.println("<a href=\"show.html\">Go Back</a>");
	          }catch(Exception e) {
	        	  System.out.println("Unexpected Exception");
	          }
	      
	}

}
