package std.det;

import java.io.IOException;
import java.io.PrintWriter;

import dao.StudentDao;
import dto.StudentDto;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

public class EditServlet extends GenericServlet {
	private static final long serialVersionUID = 1L;
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
	          StudentDto oldsdto=new StudentDto();
	          StudentDto newsdto=new StudentDto();
	           oldsdto.setFname(req.getParameter("oldfname"));
	           oldsdto.setLname(req.getParameter("oldlname"));
	           newsdto.setFname(req.getParameter("newfname"));
	           newsdto.setLname(req.getParameter("newlname"));
	           try {
	           int status=new StudentDao().edit(oldsdto, newsdto);
	           if(status>0) {
	        	   out.println("<h2>Done</h2>");
	           }
	           else {
	        	   out.println("<h2>failed to update try again</h2>");
	           }
	           out.println("<a href=\"edit.html\">Go Back</a>");
	           }catch(Exception e) {
	        	   System.out.println("Unexpected Exception "+e);
	           }
	         
	}

}
