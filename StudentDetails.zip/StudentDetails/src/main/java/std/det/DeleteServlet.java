package std.det;

import java.io.IOException;
import java.io.PrintWriter;

import dao.StudentDao;
import dto.StudentDto;
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

public class DeleteServlet extends GenericServlet {
	private static final long serialVersionUID = 1L;
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
	          StudentDto sdto=new StudentDto();
	          sdto.setRollno(req.getParameter("rollno"));
	          try {
	        	  int status=new StudentDao().delete(sdto);
	        	  if(status>0){
	     	         out.println("<h2>Done</h2>"); 
	        	  }
	        	  else
	     	         out.println("<h2>failed to delete try again</h2>");
	        	  
	        	  out.println("<a href=\"delete.html\">Go Back</a>");
	          }catch(Exception e) {
	        	  System.out.println("sorry");
	        	  }

	}

}
